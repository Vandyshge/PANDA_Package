"""Run the GROMACS-format example from the extracted example directory."""

from panda_md import load_trajectory

from md_workflow import analyze


traj = load_trajectory("slit.gro", "slit.xtc")
analyze(
    traj,
    walls="resname WALL",
    liquid="resname LIQ and name O",
    rho_bulk=3.0,
    average_from="50 ps",
    average_to="200 ps",
    block="50 ps",
    prefix="gromacs",
)
