"""Analyze a slit-pore roll from a GROMACS or LAMMPS trajectory."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from panda_md import SlitPore, density_map, density_profile, fit_blocks
from panda_md.core.timing import to_picoseconds
from panda_md.plotting import plot_density_map, plot_fit


def analyze(traj, *, walls, liquid, rho_bulk, average_from, average_to, block, prefix):
    prefix = Path(prefix)
    times = traj.times_ps()
    first_ps, last_ps = float(times[0]), float(times[-1])
    average_start = to_picoseconds(average_from)
    average_end = to_picoseconds(average_to)
    if not first_ps <= average_start < average_end <= last_ps:
        raise ValueError("The averaging window must lie within the trajectory.")
    pore = SlitPore.from_trajectory(traj, walls=walls, liquid=liquid, time=average_from)
    profiles = density_profile(
        traj, pore, liquid, start=first_ps, block=block,
        bins=80, centering="pore",
    )
    average_profile = density_profile(
        traj, pore, liquid, start=average_from, stop=average_to,
        bins=80, centering="pore",
    ).mean()
    roll = pore.interface("roll")
    result = roll.fit(average_profile, density_bulk_per_nm3=rho_bulk)
    blocks = fit_blocks(roll, profiles, result.spec)
    midpoint = (blocks.block_start_ps + blocks.block_stop_ps) / 2
    angles = blocks.values("theta")
    included = (blocks.block_start_ps >= average_start) & (blocks.block_stop_ps <= average_end)

    print(f"Pore width = {pore.width_nm:.3f} nm")
    print(f"Trajectory = {first_ps:g} to {last_ps:g} ps")
    print(f"Averaging window = {average_start:g} to {average_end:g} ps")
    print(f"Blocks plotted = {len(angles)}")
    print(f"Full blocks inside averaging window = {np.count_nonzero(included)}")
    print(f"Mean-profile theta = {result.values['theta']:.2f} deg")
    if np.count_nonzero(included) >= 2:
        print(f"Block SD inside window = {np.std(angles[included], ddof=1):.2f} deg")
    print(f"Fit flags = {result.problems()}")

    profiles.save(prefix.with_name(prefix.name + "-blocks.npz"))
    average_profile.save(prefix.with_name(prefix.name + "-average.npz"))
    density = density_map(
        traj, pore, liquid, shape="roll", start=average_from, stop=average_to, bins=(65, 40),
    )
    figure = plt.figure(figsize=(9, 7), layout="constrained")
    grid = figure.add_gridspec(2, 2)
    fit_ax = figure.add_subplot(grid[0, 0])
    block_ax = figure.add_subplot(grid[0, 1])
    map_ax = figure.add_subplot(grid[1, :])
    plot_fit(result, ax=fit_ax)
    fit_ax.set_title("Fit of the averaged profile")
    fit_ax.legend(frameon=False, loc="lower center", fontsize=9)
    block_ax.axvspan(average_start, average_end, color="#e7f0df",
                     label=f"Average: {average_start:g}–{average_end:g} ps")
    block_ax.axvline(average_start, color="#52763c", linestyle=":", linewidth=1.4)
    block_ax.plot(midpoint, angles, color="#8797a1", linewidth=1)
    block_ax.scatter(midpoint[~included], angles[~included], color="#677785", zorder=3)
    block_ax.scatter(midpoint[included], angles[included], color="#365e88", zorder=3)
    block_ax.axhline(result.values["theta"], color="#a65d23", linestyle="--",
                     linewidth=1.3, label="Fit of averaged profile")
    block_ax.set(title="Angle across the full trajectory", xlim=(first_ps, last_ps),
                 xlabel="Time (ps)", ylabel="Contact angle (deg)")
    block_ax.legend(frameon=False, loc="best", fontsize=9)
    plot_density_map(density, ax=map_ax)
    map_ax.set_title("Density map in the averaging window")
    figure.savefig(prefix.with_name(prefix.name + "-diagnostics.png"), dpi=160)
    plt.close(figure)
