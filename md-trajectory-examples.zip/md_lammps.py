"""Run the LAMMPS-format example from the extracted example directory."""

from panda_md import load_trajectory

from md_workflow import analyze


traj = load_trajectory(
    "slit.data", "slit.lammpstrj",
    atom_style="id type x y z",
    dt=0.002,  # ps per integration step; dump interval is 5000 steps
)
analyze(
    traj,
    walls="type 1",
    liquid="type 2",
    rho_bulk=3.0,
    average_from="50 ps",
    average_to="200 ps",
    block="50 ps",
    prefix="lammps",
)
